#pragma once

bool strings_compare(const char *string1, const char *string2);

int equal_strings(const char *string1, const char *string2);

void str_copy(const char *line, char *string);

#pragma once

bool Strings_compare(const char *string1, const char *string2);

int Equal_strings(const char *string1, const char *string2);

void Str_copy(const char *line, char *string);
